/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: notraore <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/19 14:37:22 by notraore          #+#    #+#             */
/*   Updated: 2017/06/14 16:26:40 by notraore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "toolbox.h"

int		pressed_key(int keycode, void *param);
int		mouse_key(int keycode, int x, int y, void *param);

int		main(void)
{
	void *mlx;
	void *win;
	void *img;
	int *img_data;
	int	bpp;
	int	sl;
	int	end;

	int color = 0xFFFFFF;

	mlx = mlx_init();
	win = mlx_new_window(mlx, 900, 900, "test");
	img = mlx_new_image(mlx, 900, 900);
	img_data = (int *)mlx_get_data_addr(img, &bpp, &sl, &end);

	int screenx = (10 - 10) * 15;
	int screeny = (10 + 10) * 15;

	int x = 50, x1 = 170;
	while (x < x1)
	{
		mlx_pixel_put(mlx, win, x, y, 0xFFFFFF);
		x++;
	}

	// mlx_put_image_to_window(mlx, win, img, 0, 0);
	mlx_key_hook(win, pressed_key, 0);
	mlx_mouse_hook(win, mouse_key, 0);
	mlx_loop(mlx);
	return (0);
}

int		pressed_key(int keycode, void *param)
{
	t_tool	tool;
	if (keycode == 53)
		exit(0);
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}

int		mouse_key(int keycode, int x, int y, void *param)
{
	t_tool	tool;
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}