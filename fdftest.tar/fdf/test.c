#include "mlx.h"
#include "toolbox.h"

void		TraceSegmentNaif (int x0, int y0, int dx, int dy, void* mlx, void* win);
int			Round (float x);
int			pressed_key(int keycode, void *param);
int			mouse_key(int keycode, int x, int y, void *param);
void		ft_line(int x0, int y0, int x1, int y1, int len, void *mlx, void *win);


int		main(void)
{
	void *mlx;
	void *win;
	void *img;
	int *img_data;
	int	bpp;
	int	sl;
	int	end;

	int color = 0xFFFFFF;

	mlx = mlx_init();
	win = mlx_new_window(mlx, 900, 900, "test");
	img = mlx_new_image(mlx, 900, 900);
	img_data = (int *)mlx_get_data_addr(img, &bpp, &sl, &end);
	
	int i = 400;
	while (i <= 500)
	{
		img_data[(0+4*800*2)+(0+4+i)] = 0xFF;
		img_data[(0+4*1500*2)+(0+4+i)] = 0xFF;
		img_data[(0+4*2500*2)+(0+4+i)] = 0xFF;
		img_data[(0+4*3500*2)+(0+4+i)] = 0xFF;
		// img_data[(0+4*4500*2)+(0+4*i)] = 0xFF;
		// img_data[(0+4*5500*2)+(0+4*i)] = 0xFF;
		// img_data[(0+4*6500*2)+(0+4*i)] = 0xFF;
		// img_data[(0+4*7500*2)+(0+4*i)] = 0xFF;
		i++;
	}
	// i = 55;
	// while(i < 500)
	// {
	// 	img_data[(0+4*55)] = 0x00FFFFFF;
	// 	i++;
	// }
	// ft_line(250, 300, 725, 600, 300, mlx, win);
	// ft_line(550, 300, 725, 600, 300, mlx, win);
	// ft_line(550, 300, 725, 600, 300, mlx, win);
	// ft_line(250, 300, 725, 600, 300, mlx, win);
	// img_data[0+4*50*222] = color;
	// img_data[0+4*50*222+1] = color;
	// img_data[0+4*50*222+2] = color;
	// img_data[0+4*50*222+3] = color;
	mlx_put_image_to_window(mlx, win, img, 0, 0);
	mlx_key_hook(win, pressed_key, 0);
	mlx_mouse_hook(win, mouse_key, 0);
	mlx_loop(mlx);
	return (0);
}

int		Round(float x)
{
	return (int)(x + 0.5);
}

void	TraceSegmentNaif(int x0, int y0, int dx, int dy, void* mlx, void* win)
{

	int i, x, y;
	float m = ((float) dy / ((float) dx));
	for (i = 0 ; i < dx ; i++)
	{
		x = x0 + i;
		y = Round(y0 + m * i);
		mlx_pixel_put(mlx, win, x, y, 0x00FF00A0);
	}
}

int		pressed_key(int keycode, void *param)
{
	t_tool	tool;
	if (keycode == 53)
		exit(0);
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}

int		mouse_key(int keycode, int x, int y, void *param)
{
	t_tool	tool;
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}

void ft_line(int x0, int y0, int x1, int y1, int len, void *mlx, void *win)
{
	t_line horse;

	int color = 0xFFFFFF;
	horse.dx = abs(x1-x0);
	horse.sx = x0 < x1 ? 1 : -1;
	horse.dy = abs(y1-y0);
	horse.sy = y0 < y1 ? 1 : -1; 
	horse.err = (horse.dx>horse.dy ? horse.dx : -horse.dy)/2;
	horse.e2 = 0;
	int i = 0;
	while(i <= len)
	{
		mlx_pixel_put(mlx, win, x0, y0, color);
		if (x0 == x1 && y0 == y1)
			break;
		horse.e2 = horse.err;
		if (horse.e2 >-horse.dx)
		{
			horse.err -= horse.dy;
			x0 += horse.sx;
		}
		if (horse.e2 < horse.dy)
		{
			horse.err += horse.dx;
			y0 += horse.sy;
		}
		i++;
		color--;
	}
}
