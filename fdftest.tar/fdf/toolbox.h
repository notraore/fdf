#ifndef __TOOLBOX_H
# define __TOOLBOX_H

# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>
# include "./libft/libft.h"
# include "minilibx/mlx.h"

# define ABS(Value) (Value < 0 ? (-Value) : (Value))

# define WIDTH 1920
# define HEIGHT 1080
# define LEN 70
typedef struct		s_tool
{
	int 	x;
	int 	y;
	int		fd;
	int		value;
	char	*line;
	void	*mlx;
	void	*win;
	void	**img;
}			t_tool;

typedef struct		s_split
{
	char				**stock;
	struct	s_split		*next;
}					t_split;

typedef struct 		s_line
{
	int dx;
	int	sx;
	int dy;
	int sy;
	int err;
	int e2;
}					t_line;

int		get_next_line(int fd, char **line);
// void	ft_line(int x0, int y0, int x1, int y1, void *mlx, void *win);

#endif
