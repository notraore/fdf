/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: notraore <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/19 14:37:22 by notraore          #+#    #+#             */
/*   Updated: 2017/07/03 19:33:50 by notraore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "toolbox.h"

int		pressed_key(int keycode);
int		mouse_key(int keycode);

int		main(int argc, char **argv)
{
	t_tool		tool;
	int 		i = 0;
	int			j = 0;
	int			value = 0;
	char		*line;
	t_split		*table;
	t_split		*tmp;
	int tile = 0;
	(void)argc;

	tool.mlx = mlx_init();
	tool.win = mlx_new_window(tool.mlx, WIDTH, HEIGHT, "FDF 1920x1080");
	if (!(tool.fd = open(argv[1], O_RDONLY)))
		return (0);
	tool.x = 755 ;
	tool.y = 255;
	table = (t_split *)malloc(sizeof(t_split));
	tmp = table;
	while ((value = get_next_line(tool.fd, &line)) == 1)
	{
		tmp->stock = ft_strsplit(line, ' ');
		tmp->next = (t_split *)malloc(sizeof(t_split));
		tmp = tmp->next;
	}
	tmp->stock = NULL;
	tmp->next = NULL;
	tmp = table;

	while (tmp->next)
	{
		while (tmp->stock[i])
		{
			if (ft_atoi(tmp->stock[i]) == 0)
				mlx_pixel_put(tool.mlx, tool.win, tool.x, tool.y, 0xFFFFFF);
			if (ft_atoi(tmp->stock[i]) == 10)
				mlx_pixel_put(tool.mlx, tool.win, tool.x, tool.y - 76, 0xFF0000);
			tool.x += 15;
			i++;
		}
		tile += 15;
		tool.y += 10;
		tool.x = 755 + tile;
		i = 0;
		tmp = tmp->next;	
	}
	mlx_key_hook(tool.win, pressed_key, 0);
	mlx_mouse_hook(tool.win, mouse_key, 0);
	mlx_loop(tool.mlx);
	return (0);
}

int		pressed_key(int keycode)
{
	if (keycode == 53)
		exit(0);
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}

int		mouse_key(int keycode)
{
	ft_putstr("Jai bien la key numero "), 
	ft_putnbr(keycode);
	ft_putchar('\n');
	return (0);
}
